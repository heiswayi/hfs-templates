HFS Template: HelloKitty

HOW TO USE
==========

1. First, you need to download WampServer because you need to host _TPLRESOURCES folder.
   
   HOW TO DO THIS?
   ===============
   After installing WampServer, you will have your 'www' folder maybe in your C:\.
   By default, when you type 'http://localhost' or 'http://172.0.0.1' in your web browser
   you will be redirected to index.php file in 'www' folder created by WampServer.
   
   What you need to do is just place _TPLRESOURCES folder into directory 'www'.
   
2. Open or run hfs.exe program, make sure you're in Expert mode, go to Menu > Edit HTML template...

3. Import HelloKitty.tpl file.

4. After the HelloKitty.tpl file loaded, you need to change or replace 'http://localhost:8080' to 'http://localhost' 
   where 'http://localhost' is your web service activated by WampServer.
   
5. Done! You should be able to see your HFS by clicking on 'Open in browser' in your hfs.exe program.

That's all.

-Heiswayi Nrird
   