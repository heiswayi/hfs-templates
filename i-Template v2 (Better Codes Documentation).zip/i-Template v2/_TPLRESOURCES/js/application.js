!function ($) {
  $(function(){

    $('span#tip-protected, i#tip-link, i#tip-folder, img#tip-bandwidth').tooltip();

  })
}(window.jQuery)